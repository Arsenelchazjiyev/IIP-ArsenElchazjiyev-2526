using System;

namespace ConsoleReisbureau
{
   class Program
   {
      static void Main(string[] args)
      {
		  Console.WriteLine("Welkom bij Reisbureau Ibiza 🌍");
		  Console.WriteLine("(a) Reisgegevens invoeren");
		  Console.WriteLine("(b) Boeking bekijken");
		  Console.WriteLine("(q) Betalen en afsluiten");
		  Console.WriteLine("Maak uw keuze ");
		  string keuzeA = "a";
		  string keuzeB = "b";
		  string keuze = Console.ReadLine();
		  Console.WriteLine($"Je koos {keuze}");
		  

		  
		  
		  
		  /* Console.WriteLine("Aantal personen");
		  Console.WriteLine("Leeftijd persoon 1");
		  int persoon1 = Convert.ToInt32(Console.ReadLine);
		  Console.WriteLine("Leeftijd persoon 2");
		  int persoon2 = Convert.ToInt32(Console.ReadLine);
		  Console.WriteLine("Leeftijd persoon 3");
		  int persoon3 = Convert.ToInt32(Console.ReadLine);
		  Console.WriteLine("Leeftijd persoon 4");
		  int persoon4 = Convert.ToInt32(Console.ReadLine);
		  const double kinderprijs = 699;
		  const double volwassenen = 899;
		  const double toeslagkredietkaart = 3;
		  const int leeftijdsgrens = 16 */
		  
		  
		  
	  }
   }
}